#pragma once

#define HTTP_SERVER "999.999.999.999"
#define HTTP_PORT 80

#define TFTP_SERVER "999.999.999.999"
