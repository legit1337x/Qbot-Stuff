sudo apt install pip
pip install discord.py
pip install colorama
pip install aiohttp
