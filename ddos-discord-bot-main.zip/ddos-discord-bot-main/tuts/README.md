I made this because some people actually don't understand this bot.
